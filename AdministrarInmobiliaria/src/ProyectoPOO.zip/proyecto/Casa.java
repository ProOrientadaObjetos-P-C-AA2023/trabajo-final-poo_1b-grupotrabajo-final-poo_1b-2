package proyecto;

import java.io.Serializable;

class Casa implements Serializable {
    private Propietario propietario;
    private double precioMetroCuadrado;
    private double metrosCuadrados;
    private String barrio;
    private String ciudad;
    private int numeroCuartos;
    private Constructora constructora;
    public double getCostoFinal() {
        return metrosCuadrados * precioMetroCuadrado;
    }
    public Casa(Propietario propietario, double precioMetroCuadrado, double metrosCuadrados, String barrio, String ciudad, int numeroCuartos, Constructora constructora) {
        this.propietario = propietario;
        this.precioMetroCuadrado = precioMetroCuadrado;
        this.metrosCuadrados = metrosCuadrados;
        this.barrio = barrio;
        this.ciudad = ciudad;
        this.numeroCuartos = numeroCuartos;
        this.constructora = constructora;
    }
    @Override
    public String toString() {
        return "Casa{" +
                "propietario=" + propietario +
                ", precioMetroCuadrado=" + precioMetroCuadrado +
                ", metrosCuadrados=" + metrosCuadrados +
                ", barrio='" + barrio + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", numeroCuartos=" + numeroCuartos +
                ", constructora=" + constructora +
                '}';
    }
}