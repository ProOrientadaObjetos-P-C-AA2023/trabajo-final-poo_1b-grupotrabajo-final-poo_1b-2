package proyecto;

import java.io.Serializable;

class Departamento implements Serializable {
    private Propietario propietario;
    private double precioMetroCuadrado;
    private double metrosCuadrados;
    private double valorAlicuotaMensual;
    private String barrio;
    private String ciudad;
    private String nombreEdificio;
    private String ubicacionDepartamento;
    private Constructora constructora;

    public Departamento(Propietario propietario, double precioMetroCuadrado, double metrosCuadrados, double valorAlicuotaMensual, String barrio, String ciudad, String nombreEdificio, String ubicacionDepartamento, Constructora constructora) {
        this.propietario = propietario;
        this.precioMetroCuadrado = precioMetroCuadrado;
        this.metrosCuadrados = metrosCuadrados;
        this.valorAlicuotaMensual = valorAlicuotaMensual;
        this.barrio = barrio;
        this.ciudad = ciudad;
        this.nombreEdificio = nombreEdificio;
        this.ubicacionDepartamento = ubicacionDepartamento;
        this.constructora = constructora;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    public double getPrecioMetroCuadrado() {
        return precioMetroCuadrado;
    }

    public void setPrecioMetroCuadrado(double precioMetroCuadrado) {
        this.precioMetroCuadrado = precioMetroCuadrado;
    }

    public double getMetrosCuadrados() {
        return metrosCuadrados;
    }

    public void setMetrosCuadrados(double metrosCuadrados) {
        this.metrosCuadrados = metrosCuadrados;
    }

    public double getValorAlicuotaMensual() {
        return valorAlicuotaMensual;
    }

    public void setValorAlicuotaMensual(double valorAlicuotaMensual) {
        this.valorAlicuotaMensual = valorAlicuotaMensual;
    }

    public String getBarrio() {
        return barrio;
    }

    public void setBarrio(String barrio) {
        this.barrio = barrio;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getNombreEdificio() {
        return nombreEdificio;
    }

    public void setNombreEdificio(String nombreEdificio) {
        this.nombreEdificio = nombreEdificio;
    }

    public String getUbicacionDepartamento() {
        return ubicacionDepartamento;
    }

    public void setUbicacionDepartamento(String ubicacionDepartamento) {
        this.ubicacionDepartamento = ubicacionDepartamento;
    }

    public Constructora getConstructora() {
        return constructora;
    }

    public void setConstructora(Constructora constructora) {
        this.constructora = constructora;
    }

    public double getCostoFinal() {
        return (metrosCuadrados * precioMetroCuadrado) + (valorAlicuotaMensual * 12);
    }

    @Override
    public String toString() {
        return "Departamento:\n" +
                "Propietario: " + propietario +
                "\nPrecio por metro cuadrado: " + precioMetroCuadrado +
                "\nMetros cuadrados: " + metrosCuadrados +
                "\nValor de la alícuota mensual: " + valorAlicuotaMensual +
                "\nBarrio: " + barrio +
                "\nCiudad: " + ciudad +
                "\nNombre del edificio: " + nombreEdificio +
                "\nUbicación del departamento: " + ubicacionDepartamento +
                "\nConstructora: " + constructora +
                "\nCosto final: " + getCostoFinal();
    }
}
