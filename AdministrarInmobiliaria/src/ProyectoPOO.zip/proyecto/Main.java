package proyecto;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Inmobiliaria inmobiliaria = new Inmobiliaria();

        // Ejemplo de uso: agregar propietarios
        Propietario propietario1 = new Propietario("Juan", "Perez", "123456789");
        Propietario propietario2 = new Propietario("Maria", "Gomez", "987654321");
        inmobiliaria.agregarPropietario(propietario1);
        inmobiliaria.agregarPropietario(propietario2);

        // Ejemplo de uso: agregar barrios
        Barrio barrio1 = new Barrio("Centro", "Cerca de la plaza principal");
        Barrio barrio2 = new Barrio("Residencial", "Zona residencial tranquila");
        inmobiliaria.agregarBarrio(barrio1);
        inmobiliaria.agregarBarrio(barrio2);

        // Ejemplo de uso: agregar ciudades
        Ciudad ciudad1 = new Ciudad("Ciudad A", "Provincia X");
        Ciudad ciudad2 = new Ciudad("Ciudad B", "Provincia Y");
        inmobiliaria.agregarCiudad(ciudad1);
        inmobiliaria.agregarCiudad(ciudad2);

        // Ejemplo de uso: agregar constructoras
        Constructora constructora1 = new Constructora("Constructora 1", "ID001");
        Constructora constructora2 = new Constructora("Constructora 2", "ID002");
        inmobiliaria.agregarConstructora(constructora1);
        inmobiliaria.agregarConstructora(constructora2);

        // Ejemplo de uso: agregar casas
        Casa casa1 = new Casa(propietario1, 1000, 200, barrio1.getNombre(), ciudad1.getNombre(), 3, constructora1);
        Casa casa2 = new Casa(propietario2, 1500, 150, barrio2.getNombre(), ciudad2.getNombre(), 2, constructora2);
        inmobiliaria.agregarCasa(casa1);
        inmobiliaria.agregarCasa(casa2);

        Departamento departamento1 = new Departamento(propietario1, 2000, 100, 200, barrio1.getNombre(), ciudad1.getNombre(), "Edificio A", "Piso 1", constructora1);
        Departamento departamento2 = new Departamento(propietario2, 2500, 150, 300, barrio2.getNombre(), ciudad2.getNombre(), "Edificio B", "Piso 2", constructora2);
        inmobiliaria.agregarDepartamento(departamento1);
        inmobiliaria.agregarDepartamento(departamento2);

        // Ejemplo de uso: listar propietarios
        List<Propietario> propietarios = inmobiliaria.listarPropietarios();
        for (Propietario propietario : propietarios) {
            System.out.println(propietario);
        }

        // Ejemplo de uso: listar barrios
        List<Barrio> barrios = inmobiliaria.listarBarrios();
        for (Barrio barrio : barrios) {
            System.out.println(barrio);
        }

        // Ejemplo de uso: listar ciudades
        List<Ciudad> ciudades = inmobiliaria.listarCiudades();
        for (Ciudad ciudad : ciudades) {
            System.out.println(ciudad);
        }

        // Ejemplo de uso: listar constructoras
        List<Constructora> constructoras = inmobiliaria.listarConstructoras();
        for (Constructora constructora : constructoras) {
            System.out.println(constructora);
        }

        // Ejemplo de uso: listar casas
        List<Casa> casas = inmobiliaria.listarCasas();
        for (Casa casa : casas) {
            System.out.println(casa);
        }

        // Ejemplo de uso: listar departamentos
        List<Departamento> departamentos = inmobiliaria.listarDepartamentos();
        for (Departamento departamento : departamentos) {
            System.out.println(departamento);
        }
    }
}