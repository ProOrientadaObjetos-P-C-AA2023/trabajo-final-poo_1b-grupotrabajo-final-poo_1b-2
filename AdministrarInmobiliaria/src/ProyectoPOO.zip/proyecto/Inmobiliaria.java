package proyecto;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Inmobiliaria {
    private List<Propietario> propietarios;
    private List<Barrio> barrios;
    private List<Ciudad> ciudades;
    private List<Constructora> constructoras;
    private List<Casa> casas;
    private List<Departamento> departamentos;

    public Inmobiliaria() {
        this.propietarios = cargarObjetos("propietarios.dat");
        this.barrios = cargarObjetos("barrios.dat");
        this.ciudades = cargarObjetos("ciudades.dat");
        this.constructoras = cargarObjetos("constructoras.dat");
        this.casas = cargarObjetos("casas.dat");
        this.departamentos = cargarObjetos("departamentos.dat");
    }

    public void agregarPropietario(Propietario propietario) {
        propietarios.add(propietario);
        guardarObjetos(propietarios, "propietarios.dat");
    }

    public void agregarBarrio(Barrio barrio) {
        barrios.add(barrio);
        guardarObjetos(barrios, "barrios.dat");
    }

    public void agregarCiudad(Ciudad ciudad) {
        ciudades.add(ciudad);
        guardarObjetos(ciudades, "ciudades.dat");
    }

    public void agregarConstructora(Constructora constructora) {
        constructoras.add(constructora);
        guardarObjetos(constructoras, "constructoras.dat");
    }

    public void agregarCasa(Casa casa) {
        casas.add(casa);
        guardarObjetos(casas, "casas.dat");
    }
    public void agregarDepartamento(Departamento departamento) {
        departamentos.add(departamento);
        guardarObjetos(departamentos, "departamentos.dat");
    }
    public List<Propietario> listarPropietarios() {
        return cargarObjetos("propietarios.dat");
    }
    public List<Departamento> listarDepartamentos() {
        return cargarObjetos("departamentos.dat");
    }

    public List<Barrio> listarBarrios() {
        return cargarObjetos("barrios.dat");
    }

    public List<Ciudad> listarCiudades() {
        return cargarObjetos("ciudades.dat");
    }

    public List<Constructora> listarConstructoras() {
        return cargarObjetos("constructoras.dat");
    }

    public List<Casa> listarCasas() {
        return cargarObjetos("casas.dat");
    }

    private void guardarObjetos(List<?> objetos, String archivo) {
        try {
            FileOutputStream fileOut = new FileOutputStream(archivo);
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(objetos);
            objectOut.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private <T> List<T> cargarObjetos(String archivo) {
        List<T> objetos = new ArrayList<>();
        try {
            FileInputStream fileIn = new FileInputStream(archivo);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            objetos = (List<T>) objectIn.readObject();
            objectIn.close();
            fileIn.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return objetos;
    }

}
